# ChangeLogs

## v1.0.1
added localhost url handling for visiting localhost urls

## v1.0.0
its a initial version